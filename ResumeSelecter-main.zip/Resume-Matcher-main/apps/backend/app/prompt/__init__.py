from .base import PromptFactory

prompt_factory = PromptFactory()
__all__ = ["prompt_factory"]
